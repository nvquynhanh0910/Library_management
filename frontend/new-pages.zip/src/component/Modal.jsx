// component/Modal.jsx – Modal dùng chung
import React from 'react';
const Modal = ({ isOpen, onClose, title, children, width = '480px' }) => {
  if (!isOpen) return null;
  return (
    <div onClick={onClose} style={{ position:'fixed',inset:0,backgroundColor:'rgba(0,0,0,0.45)',
      display:'flex',justifyContent:'center',alignItems:'center',zIndex:1000 }}>
      <div onClick={e=>e.stopPropagation()} style={{ background:'white',borderRadius:'10px',
        width,maxWidth:'95vw',boxShadow:'0 8px 40px rgba(0,0,0,0.18)',maxHeight:'90vh',overflowY:'auto' }}>
        <div style={{ display:'flex',justifyContent:'space-between',alignItems:'center',
          padding:'18px 24px',borderBottom:'2px solid #7DA78C' }}>
          <h3 style={{ margin:0,color:'#333',fontSize:'16px' }}>{title}</h3>
          <button onClick={onClose} style={{ background:'none',border:'none',fontSize:'22px',
            cursor:'pointer',color:'#999',lineHeight:1,padding:'0 4px' }}>×</button>
        </div>
        <div style={{ padding:'24px' }}>{children}</div>
      </div>
    </div>
  );
};
export default Modal;
