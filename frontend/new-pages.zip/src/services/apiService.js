// ============================================================
// services/apiService.js
// Tập trung toàn bộ hàm gọi API (Axios) cho hệ thống thư viện
// Base URL trỏ vào backend Node.js Express (port 3001)
// ============================================================
import axios from 'axios';

const api = axios.create({
  baseURL: 'http://localhost:3001/api',
  timeout: 10000,
});

// Tự động gắn JWT token vào mọi request (sau khi đăng nhập)
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('authToken');
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

// ─────────────────────────────────────────────
// PHÂN HỆ 1A: ĐỘC GIẢ  (bảng DocGia)
// Fields: MaThanhVien, HoTen, Email, SoDienThoai
// ─────────────────────────────────────────────
export const docGiaApi = {
  getAll:       ()          => api.get('/docgia'),
  getById:      (id)        => api.get(`/docgia/${id}`),
  create:       (data)      => api.post('/docgia', data),
  update:       (id, data)  => api.put(`/docgia/${id}`, data),
  delete:       (id)        => api.delete(`/docgia/${id}`),
};

// ─────────────────────────────────────────────
// PHÂN HỆ 1B: NHÂN VIÊN  (bảng NhanVien)
// Fields: MaNhanVien, TenNhanVien, ChucVu, Username, Password
// ─────────────────────────────────────────────
export const nhanVienApi = {
  getAll:       ()          => api.get('/nhanvien'),
  getById:      (id)        => api.get(`/nhanvien/${id}`),
  create:       (data)      => api.post('/nhanvien', data),
  update:       (id, data)  => api.put(`/nhanvien/${id}`, data),
  delete:       (id)        => api.delete(`/nhanvien/${id}`),
};

// ─────────────────────────────────────────────
// PHÂN HỆ 2A: PHIẾU MƯỢN  (bảng PhieuMuon + MuonSach)
// PhieuMuon: MaPhieu, NgayLapPhieu, MaThanhVien, MaNhanVienLap, MaNhanVienThu
// MuonSach:  MaPhieu, MaCuonSach, HinhThucMuon, HanTra, NgayTraThucTe, TinhTrangKhiTra, TienPhatPhatSinh
// ─────────────────────────────────────────────
export const phieuMuonApi = {
  getAll:       ()          => api.get('/phieumuon'),
  getById:      (id)        => api.get(`/phieumuon/${id}`),
  // Tạo phiếu mượn - gửi kèm danh sách MaCuonSach
  create:       (data)      => api.post('/phieumuon', data),
  // Xử lý trả sách - cập nhật NgayTraThucTe + TinhTrangKhiTra
  traSach:      (data)      => api.post('/phieumuon/trasach', data),
};

// ─────────────────────────────────────────────
// PHÂN HỆ 2B: PHIẾU PHẠT  (bảng PhieuPhat)
// Fields: MaPhieuPhat, NgayLapPhieu, TrangThaiThanhToan,
//         TongTienPhat, TenHinhPhat, MaPhieu, MaCuonSach
// ─────────────────────────────────────────────
export const phieuPhatApi = {
  getAll:       ()          => api.get('/phieuphat'),
  // Cập nhật trạng thái thanh toán phiếu phạt
  updateThanhToan: (id, trangThai) =>
    api.patch(`/phieuphat/${id}/thanhtoan`, { TrangThaiThanhToan: trangThai }),
};

// ─────────────────────────────────────────────
// PHÂN HỆ 3: DASHBOARD THỐNG KÊ
// Trả về JSON tổng hợp cho các Card + Chart
// ─────────────────────────────────────────────
export const dashboardApi = {
  getStats:     ()          => api.get('/dashboard/stats'),
};

export default api;
