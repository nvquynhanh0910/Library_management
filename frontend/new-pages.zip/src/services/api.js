// services/api.js – Toàn bộ hàm gọi API (mock → backend)
import { mockData } from '../data/mockdata.js';

export const USE_MOCK = true; // ← đổi false khi backend Node.js chạy
const BASE_URL = 'http://localhost:3001/api';
const delay = (ms = 300) => new Promise(r => setTimeout(r, ms));

const nextId = (arr, prefix, field) => {
  const nums = arr.map(r => parseInt((r[field] || '').replace(prefix, '')) || 0);
  return `${prefix}${String(Math.max(0, ...nums) + 1).padStart(3, '0')}`;
};

// ── DocGia ────────────────────────────────────────────────────
export const getDocGia = async () => { await delay(); return [...mockData.docgia]; };

export const createDocGia = async (data) => {
  await delay();
  const item = { MaThanhVien: nextId(mockData.docgia, 'DG', 'MaThanhVien'), ...data };
  mockData.docgia.push(item); return item;
};

export const updateDocGia = async (id, data) => {
  await delay();
  const idx = mockData.docgia.findIndex(d => d.MaThanhVien === id);
  if (idx !== -1) mockData.docgia[idx] = { ...mockData.docgia[idx], ...data };
  return mockData.docgia[idx];
};

export const deleteDocGia = async (id) => {
  await delay();
  const idx = mockData.docgia.findIndex(d => d.MaThanhVien === id);
  mockData.docgia.splice(idx, 1); return true;
};

// ── NhanVien ──────────────────────────────────────────────────
export const getNhanVien = async () => { await delay(); return [...mockData.nhanvien]; };

export const createNhanVien = async (data) => {
  await delay();
  const item = { MaNhanVien: nextId(mockData.nhanvien, 'NV', 'MaNhanVien'), ...data };
  mockData.nhanvien.push(item); return item;
};

export const updateNhanVien = async (id, data) => {
  await delay();
  const idx = mockData.nhanvien.findIndex(n => n.MaNhanVien === id);
  if (idx !== -1) mockData.nhanvien[idx] = { ...mockData.nhanvien[idx], ...data };
  return mockData.nhanvien[idx];
};

export const deleteNhanVien = async (id) => {
  await delay();
  const idx = mockData.nhanvien.findIndex(n => n.MaNhanVien === id);
  mockData.nhanvien.splice(idx, 1); return true;
};

// ── PhieuMuon / MuonSach ──────────────────────────────────────
export const getPhieuMuon = async () => { await delay(); return [...mockData.phieumuon]; };

export const getMuonSachByPhieu = async (maPhieu) => {
  await delay(); return mockData.muonsach.filter(ms => ms.MaPhieu === maPhieu);
};

export const createPhieuMuon = async (data) => {
  await delay();
  const maPhieu = nextId(mockData.phieumuon, 'PM', 'MaPhieu');
  const docgia  = mockData.docgia.find(d => d.MaThanhVien === data.MaThanhVien);
  const phieu   = { MaPhieu: maPhieu, NgayLapPhieu: new Date().toISOString().slice(0,10),
    MaThanhVien: data.MaThanhVien, HoTenDocGia: docgia?.HoTen || '',
    MaNhanVienLap: data.MaNhanVienLap, MaNhanVienThu: null, TrangThai: 'Đang mượn' };
  mockData.phieumuon.push(phieu);
  data.danhSachCuonSach.forEach(item => {
    mockData.muonsach.push({ MaPhieu: maPhieu, MaCuonSach: item.MaCuonSach,
      TenSach: item.TenSach, HinhThucMuon: item.HinhThucMuon || 'Mang về',
      HanTra: data.NgayHenTra, NgayTraThucTe: null, TinhTrangKhiTra: null, TienPhatPhatSinh: 0 });
    const cs = mockData.cuonsach.find(c => c.MaCuonSach === item.MaCuonSach);
    if (cs) cs.TrangThai = 'Đang mượn';
  });
  return phieu;
};

export const traSach = async (maPhieu, maCuonSach, ngayTraThucTe, tinhTrangKhiTra) => {
  await delay();
  const ms = mockData.muonsach.find(m => m.MaPhieu === maPhieu && m.MaCuonSach === maCuonSach);
  if (!ms) throw new Error('Không tìm thấy chi tiết mượn');
  ms.NgayTraThucTe   = ngayTraThucTe;
  ms.TinhTrangKhiTra = tinhTrangKhiTra;
  const soNgay = Math.max(0, Math.floor((new Date(ngayTraThucTe) - new Date(ms.HanTra)) / 86400000));
  ms.TienPhatPhatSinh = soNgay * 5000;
  const cs = mockData.cuonsach.find(c => c.MaCuonSach === maCuonSach);
  if (cs) cs.TrangThai = 'Sẵn sàng';
  const conLai = mockData.muonsach.filter(m => m.MaPhieu === maPhieu && !m.NgayTraThucTe);
  if (conLai.length === 0) {
    const p = mockData.phieumuon.find(p => p.MaPhieu === maPhieu);
    if (p) p.TrangThai = 'Đã trả';
  }
  return ms;
};

// ── PhieuPhat ─────────────────────────────────────────────────
export const getPhieuPhat = async () => { await delay(); return [...mockData.phieuPhat]; };

export const updateThanhToanPhieuPhat = async (id) => {
  await delay();
  const pp = mockData.phieuPhat.find(p => p.MaPhieuPhat === id);
  if (pp) pp.TrangThaiThanhToan = 'Đã thanh toán'; return pp;
};

// ── Dashboard ─────────────────────────────────────────────────
export const getDashboardStats = async () => { await delay(400); return { ...mockData.dashboard }; };

// ── Cuốn sách sẵn sàng (dùng cho form lập phiếu mượn) ────────
export const getCuonSachSanSang = async () => {
  await delay();
  return mockData.cuonsach.filter(cs => cs.TrangThai === 'Sẵn sàng').map(cs => {
    const ds = mockData.dausach.find(d => d.MaDauSach === cs.MaDauSach);
    return { ...cs, TenSach: ds?.TenSach || cs.MaDauSach };
  });
};
